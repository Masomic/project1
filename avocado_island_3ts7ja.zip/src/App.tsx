import { Authenticated, Unauthenticated, useConvexAuth, useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster, toast } from "sonner";
import { ProductList } from "./ProductList";
import { AddProductForm } from "./AddProductForm";
import { useEffect, useState } from "react";

export default function App() {
  const seedProducts = useMutation(api.products.ensureProductsSeeded);
  const { isLoading: authLoading, isAuthenticated } = useConvexAuth();
  const [showSignInForm, setShowSignInForm] = useState(false);

  useEffect(() => {
    seedProducts({});
  }, [seedProducts]);

  // If user becomes authenticated, hide the sign-in form
  useEffect(() => {
    if (isAuthenticated) {
      setShowSignInForm(false);
    }
  }, [isAuthenticated]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-pink-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4 md:px-8">
        <h2 className="text-2xl font-bold text-pink-600">Avocado Island</h2>
        <div className="flex items-center gap-4">
          <Authenticated>
            <SignOutButton />
          </Authenticated>
          <Unauthenticated>
            <button 
              onClick={() => setShowSignInForm(prev => !prev)} 
              className="btn btn-secondary"
            >
              {showSignInForm ? "Cancel" : "Login / Sign Up"}
            </button>
          </Unauthenticated>
        </div>
      </header>
      
      <main className="flex-1 p-4 md:p-8">
        <Unauthenticated>
          {showSignInForm && (
            <div className="w-full max-w-md mx-auto my-10">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-gray-800 mb-2">Welcome to Avocado Island</h1>
                <p className="text-lg text-gray-600">Discover your natural radiance.</p>
                <p className="text-md text-gray-500 mt-4">Sign in to explore our exclusive collection or manage products.</p>
              </div>
              <SignInForm />
            </div>
          )}
        </Unauthenticated>

        <Authenticated>
          <Content />
        </Authenticated>

        {/* Products visible to everyone, adjust margin if sign in form is shown */}
        <div className={`container mx-auto ${showSignInForm && !isAuthenticated ? 'mt-0' : 'mt-10'}`}>
          <h3 className="text-3xl font-semibold text-gray-700 mb-6 text-center">Our Products</h3>
          <ProductList />
        </div>
      </main>
      
      <Toaster richColors />
      <footer className="text-center p-4 border-t bg-gray-100 text-gray-600">
        © {new Date().getFullYear()} Avocado Island. All rights reserved.
      </footer>
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const isAdmin = useQuery(api.users.isAdmin);
  const userProfile = useQuery(api.users.getCurrentUserProfile); 
  
  const claimAdminRole = useMutation(api.users.claimAdminRole);
  const ensureProfileMutation = useMutation(api.users.ensureUserProfileExists);

  const [adminClaimStatus, setAdminClaimStatus] = useState<string | null>(null);
  const [profileEnsured, setProfileEnsured] = useState(false);

  useEffect(() => {
    if (loggedInUser && !profileEnsured) {
      ensureProfileMutation({})
        .then((message) => {
          setProfileEnsured(true); 
        })
        .catch(err => {
          console.error("Failed to ensure profile:", err);
          toast.error("Could not initialize user profile.");
        });
    }
  }, [loggedInUser, ensureProfileMutation, profileEnsured]);


  const handleClaimAdmin = async () => {
    setAdminClaimStatus("Processing...");
    toast.loading("Attempting to claim admin role...");
    try {
      const result = await claimAdminRole({});
      toast.dismiss();
      if (result.success) {
        toast.success(result.message);
        setAdminClaimStatus(result.message!);
      } else {
        toast.info(result.message); 
        setAdminClaimStatus(result.message!);
      }
    } catch (error) {
      toast.dismiss();
      console.error("Failed to claim admin role:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      toast.error(`Failed to claim admin role: ${errorMessage}`);
      setAdminClaimStatus(`Error: ${errorMessage}`);
    }
  };

  if (loggedInUser === undefined || isAdmin === undefined || (loggedInUser && userProfile === undefined && !profileEnsured) ) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-600"></div>
      </div>
    );
  }

  const showClaimAdminButton = loggedInUser && loggedInUser.email === "masonic8754@gmail.com" && !isAdmin;

  return (
    <div className="container mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">
          Welcome, {loggedInUser?.name ?? loggedInUser?.email ?? "Avocado Enthusiast"}!
          {isAdmin && <span className="text-sm text-pink-600 ml-2">(Admin)</span>}
        </h1>
        <p className="text-lg text-gray-600">Explore our curated collection of beauty essentials.</p>
      </div>

      {showClaimAdminButton && (
        <div className="my-6 p-4 bg-white rounded-lg shadow text-center">
          <p className="text-gray-700 mb-3">
            As the designated administrator ({loggedInUser?.email}), you can claim full admin privileges.
          </p>
          <button
            onClick={handleClaimAdmin}
            className="btn btn-primary"
            disabled={adminClaimStatus === "Processing..."}
          >
            {adminClaimStatus === "Processing..." ? "Processing..." : "Claim Admin Role"}
          </button>
          {adminClaimStatus && adminClaimStatus !== "Processing..." && (
            <p className={`mt-2 text-sm ${adminClaimStatus.startsWith("Error") ? "text-red-500" : (adminClaimStatus.includes("success") ? "text-green-500" : "text-blue-500")}`}>
              {adminClaimStatus}
            </p>
          )}
        </div>
      )}
      
      {isAdmin && (
        <div className="mb-12 p-6 bg-white rounded-lg shadow-lg">
          <h3 className="text-2xl font-semibold text-gray-700 mb-4">Add New Product (Admin)</h3>
          <AddProductForm />
        </div>
      )}
    </div>
  );
}
