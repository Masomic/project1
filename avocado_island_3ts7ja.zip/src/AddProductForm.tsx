import { FormEvent, useRef, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";
import { toast } from "sonner";

export function AddProductForm() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.products.generateUploadUrl);
  const addProduct = useMutation(api.products.addProduct);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!name || !description || !price) {
      toast.error("Please fill in all product details.");
      return;
    }

    setIsSubmitting(true);
    toast.loading("Adding product...");

    let imageStorageId: Id<"_storage"> | undefined = undefined;

    try {
      if (selectedImage) {
        const postUrl = await generateUploadUrl();
        const result = await fetch(postUrl, {
          method: "POST",
          headers: { "Content-Type": selectedImage.type },
          body: selectedImage,
        });
        const json = await result.json();
        if (!result.ok) {
          throw new Error(`Image upload failed: ${JSON.stringify(json)}`);
        }
        imageStorageId = json.storageId;
      }

      await addProduct({
        name,
        description,
        price: parseFloat(price),
        imageStorageId,
      });

      toast.success("Product added successfully!");
      setName("");
      setDescription("");
      setPrice("");
      setSelectedImage(null);
      if (imageInputRef.current) {
        imageInputRef.current.value = "";
      }
    } catch (error) {
      console.error("Failed to add product:", error);
      toast.error(`Failed to add product: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setIsSubmitting(false);
      toast.dismiss(); // Dismiss loading toast
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
          Product Name
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full px-4 py-2.5 rounded-lg bg-gray-50 border border-gray-300 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 outline-none transition-shadow shadow-sm hover:shadow-md"
          placeholder="e.g., Hydrating Face Cream"
          required
        />
      </div>
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
          Description
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="w-full px-4 py-2.5 rounded-lg bg-gray-50 border border-gray-300 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 outline-none transition-shadow shadow-sm hover:shadow-md"
          placeholder="Describe the product..."
          required
        />
      </div>
      <div>
        <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
          Price ($)
        </label>
        <input
          type="number"
          id="price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          step="0.01"
          min="0"
          className="w-full px-4 py-2.5 rounded-lg bg-gray-50 border border-gray-300 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 outline-none transition-shadow shadow-sm hover:shadow-md"
          placeholder="e.g., 29.99"
          required
        />
      </div>
      <div>
        <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">
          Product Image
        </label>
        <input
          type="file"
          id="image"
          accept="image/*"
          ref={imageInputRef}
          onChange={(e) => setSelectedImage(e.target.files ? e.target.files[0] : null)}
          className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-pink-50 file:text-pink-700 hover:file:bg-pink-100"
        />
        {selectedImage && (
          <p className="text-xs text-gray-500 mt-1">Selected: {selectedImage.name}</p>
        )}
      </div>
      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full px-6 py-3 rounded-lg bg-pink-600 text-white font-semibold hover:bg-pink-700 transition-colors shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-opacity-50"
      >
        {isSubmitting ? "Adding..." : "Add Product"}
      </button>
    </form>
  );
}
