import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  products: defineTable({
    name: v.string(),
    description: v.string(),
    price: v.number(),
    imageStorageId: v.optional(v.id("_storage")),
    // sellerId: v.id("users"), // To link product to a seller if needed
  })
  .index("by_price", ["price"]),
  
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("user")),
  }).index("by_userId", ["userId"]),
  // orders: defineTable({ ... }), // For a full e-commerce app
  // cartItems: defineTable({ ... }), // For a shopping cart
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
