import { v } from "convex/values";
import { query, mutation, internalMutation } from "./_generated/server";
import { api, internal } from "./_generated/api";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Doc, Id } from "./_generated/dataModel";

const ADMIN_EMAIL = "masonic8754@gmail.com"; // Specific admin email

// Internal mutation to create or update a user profile
export const upsertUserProfile = internalMutation({
  args: { userId: v.id("users"), role: v.union(v.literal("admin"), v.literal("user")) },
  handler: async (ctx, { userId, role }) => {
    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      if (existingProfile.role !== role) {
        await ctx.db.patch(existingProfile._id, { role });
      }
      return existingProfile._id;
    } else {
      return await ctx.db.insert("userProfiles", { userId, role });
    }
  },
});

// Query to get the current user's profile
export const getCurrentUserProfile = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    
    return userProfile; // Will be null if not yet created
  },
});

// Query to check if the current user is an admin
export const isAdmin = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return false;
    }
    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    return userProfile?.role === "admin";
  },
});

// Mutation for the designated user to claim the admin role
export const claimAdminRole = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated.");
    }

    const user = await ctx.db.get(userId);
    if (!user || !user.email) { // Ensure email exists for the user
      throw new Error("User data or email not found.");
    }

    const existingProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (user.email === ADMIN_EMAIL) {
      // This user is the designated admin.
      // Check if any other user is currently admin.
      const currentAdmins = await ctx.db
        .query("userProfiles")
        .filter((q) => q.eq(q.field("role"), "admin"))
        .collect();

      for (const adminProfile of currentAdmins) {
        if (adminProfile.userId !== userId) {
          // Another user is admin, demote them.
          await ctx.db.patch(adminProfile._id, { role: "user" });
        }
      }

      // Set this user as admin.
      if (existingProfile) {
        await ctx.db.patch(existingProfile._id, { role: "admin" });
      } else {
        await ctx.db.insert("userProfiles", { userId, role: "admin" });
      }
      return { success: true, message: "Admin role claimed successfully." };
    } else {
      // This user is not the designated admin. Ensure they have a "user" profile.
      if (existingProfile) {
        if (existingProfile.role === "admin") {
          // This user was admin but is not the designated ADMIN_EMAIL, demote.
          await ctx.db.patch(existingProfile._id, { role: "user" });
          return { success: false, message: "Role updated to user. Only the designated email can be admin." };
        }
      } else {
        await ctx.db.insert("userProfiles", { userId, role: "user" });
      }
      return { success: false, message: "Only the designated email can be admin. Your role is 'user'." };
    }
  },
});

// Helper to ensure user profile exists, defaults to 'user' role
export const ensureUserProfileExists = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated.");
    }
    
    const user = await ctx.db.get(userId);
    if (!user) {
      throw new Error("User data not found.");
    }

    let userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile) {
      // If user is the designated admin and has no profile, create as admin.
      // Otherwise, create as user.
      const role = user.email === ADMIN_EMAIL ? "admin" : "user";
      
      // If designated admin, check if another admin exists and demote them.
      if (role === "admin") {
        const currentAdmins = await ctx.db
          .query("userProfiles")
          .filter((q) => q.eq(q.field("role"), "admin"))
          .collect();
        for (const adminProfile of currentAdmins) {
          if (adminProfile.userId !== userId) {
            await ctx.db.patch(adminProfile._id, { role: "user" });
          }
        }
      }
      
      await ctx.db.insert("userProfiles", { userId, role });
      return `User profile created with '${role}' role.`;
    }
    // If profile exists and user is ADMIN_EMAIL but role is 'user', promote.
    // And demote any other admin.
    else if (user.email === ADMIN_EMAIL && userProfile.role === "user") {
        const currentAdmins = await ctx.db
          .query("userProfiles")
          .filter((q) => q.eq(q.field("role"), "admin"))
          .collect();
        for (const adminProfile of currentAdmins) {
          if (adminProfile.userId !== userId) {
            await ctx.db.patch(adminProfile._id, { role: "user" });
          }
        }
        await ctx.db.patch(userProfile._id, {role: "admin"});
        return "User profile updated to 'admin' role.";
    }
    // If profile exists and user is NOT ADMIN_EMAIL but role is 'admin', demote.
    else if (user.email !== ADMIN_EMAIL && userProfile.role === "admin") {
        await ctx.db.patch(userProfile._id, {role: "user"});
        return "User profile updated to 'user' role as not designated admin.";
    }

    return "User profile already exists and is correctly configured.";
  }
});
