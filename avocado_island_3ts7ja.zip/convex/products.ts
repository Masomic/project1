import { v } from "convex/values";
import { query, mutation, internalMutation } from "./_generated/server";
import { api, internal } from "./_generated/api";
import { Id } from "./_generated/dataModel";
// import { getAuthUserId } from "@convex-dev/auth/server"; // Not directly used here, role check is via api.users.isAdmin

// Public query to list all products
export const listProducts = query({
  args: {},
  handler: async (ctx) => {
    const products = await ctx.db.query("products").order("desc").collect();
    return Promise.all(
      products.map(async (product) => {
        const imageUrl = product.imageStorageId
          ? await ctx.storage.getUrl(product.imageStorageId)
          : null;
        return {
          ...product,
          imageUrl,
        };
      })
    );
  },
});

// Public query to get a single product
export const getProduct = query({
  args: { productId: v.id("products") },
  handler: async (ctx, args) => {
    const product = await ctx.db.get(args.productId);
    if (!product) {
      return null;
    }
    const imageUrl = product.imageStorageId
      ? await ctx.storage.getUrl(product.imageStorageId)
      : null;
    return {
      ...product,
      imageUrl,
    };
  },
});

// Mutation to add a product - only for admins
export const addProduct = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    price: v.number(),
    imageStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const isAdmin: boolean = await ctx.runQuery(api.users.isAdmin);
    if (!isAdmin) {
      throw new Error("You must be an admin to add a product.");
    }

    const productId = await ctx.db.insert("products", {
      name: args.name,
      description: args.description,
      price: args.price,
      imageStorageId: args.imageStorageId,
    });
    return productId;
  },
});

// Mutation to generate an upload URL for product images - only for admins
export const generateUploadUrl = mutation(async (ctx) => {
  const isAdmin: boolean = await ctx.runQuery(api.users.isAdmin);
  if (!isAdmin) {
    throw new Error("You must be an admin to upload an image.");
  }
  return await ctx.storage.generateUploadUrl();
});


// Internal mutation to seed initial data - for development purposes
export const seedInitialProducts = internalMutation({
  args: {},
  handler: async (ctx) => {
    const existingProducts = await ctx.db.query("products").collect();
    if (existingProducts.length > 0) {
      console.log("Products already seeded.");
      return;
    }

    console.log("Seeding initial products...");
    await ctx.db.insert("products", {
      name: "Radiant Glow Serum",
      description: "A luxurious serum that revitalizes and illuminates your skin, leaving it with a radiant glow. Enriched with natural extracts and vitamins.",
      price: 49.99,
    });
    await ctx.db.insert("products", {
      name: "Velvet Touch Moisturizer",
      description: "Experience the ultimate hydration with our Velvet Touch Moisturizer. Its rich, creamy formula absorbs quickly, providing long-lasting moisture and a soft, supple feel.",
      price: 35.50,
    });
    await ctx.db.insert("products", {
      name: "Pure Cleanse Face Wash",
      description: "Gently remove impurities and makeup with our Pure Cleanse Face Wash. Formulated for all skin types, it leaves your skin feeling refreshed and clean without stripping natural oils.",
      price: 22.00,
    });
    console.log("Initial products seeded.");
  },
});

// You might want to run this once manually or via a cron job if needed
// For Chef, we can call this from main App.tsx once for demo purposes
export const ensureProductsSeeded = mutation({
  args: {},
  handler: async (ctx) => {
    const existingProducts = await ctx.db.query("products").take(1);
    if (existingProducts.length === 0) {
      await ctx.scheduler.runAfter(0, internal.products.seedInitialProducts, {});
      return "Seeding process initiated.";
    }
    return "Products already exist or seeding was previously initiated.";
  }
});
