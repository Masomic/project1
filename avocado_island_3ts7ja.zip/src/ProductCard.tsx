import { useConvexAuth } from "convex/react";
import { Doc } from "../convex/_generated/dataModel";
import { toast } from "sonner";

interface ProductCardProps {
  product: Doc<"products"> & { imageUrl: string | null };
}

export function ProductCard({ product }: ProductCardProps) {
  const { isAuthenticated } = useConvexAuth();

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      toast.info("Please sign in to add items to your cart.");
      // Here you could also trigger a modal to open the SignInForm
      // or redirect to a login page if you had one.
      return;
    }
    // Placeholder for actual add to cart logic
    toast.success(`${product.name} added to cart! (Not really, this is a placeholder)`);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl flex flex-col">
      <div className="w-full h-56 bg-gray-200 flex items-center justify-center">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <span className="text-gray-400 text-sm">No image</span>
        )}
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-xl font-semibold text-gray-800 mb-2 truncate" title={product.name}>
          {product.name}
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow" title={product.description}>
          {product.description}
        </p>
        <div className="flex justify-between items-center mt-auto">
          <p className="text-2xl font-bold text-pink-600">
            ₹{product.price.toFixed(2)}
          </p>
          <button 
            onClick={handleAddToCart}
            className="bg-pink-500 text-white px-5 py-2 rounded-lg font-semibold hover:bg-pink-600 transition-colors focus:outline-none focus:ring-2 focus:ring-pink-400 focus:ring-opacity-50"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
